This module is designed to be used only with Foundry Version 11 / CyberpunkRED-Core v0.88.2
