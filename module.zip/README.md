Use the following to install:
```
https://raw.githubusercontent.com/coopyey/vtt-SharedData/refs/heads/main/module.json
```
